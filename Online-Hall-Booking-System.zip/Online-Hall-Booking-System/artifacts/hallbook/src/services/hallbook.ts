export type Role = 'student' | 'admin';
export type UserStatus = 'active' | 'suspended';
export type BookingStatus = 'confirmed' | 'completed' | 'cancelled';

export type User = { userId: string; name: string; email: string; phone: string; password: string; role: Role; status: UserStatus; createdAt: string };
export type Hall = { hallId: string; hallName: string; capacity: number; location: string; facilities: string[]; description: string; image: string; status: 'available' | 'maintenance' };
export type Booking = { bookingId: string; userId: string; hallId: string; date: string; timeSlot: string; status: BookingStatus; createdAt: string };
export type Report = { reportId: string; bookingId: string; createdAt: string };
export type WorkspaceSettings = { reminders: boolean; autoApprove: boolean; window: string };

const keys = { users: 'hallbook.users', halls: 'hallbook.halls', bookings: 'hallbook.bookings', reports: 'hallbook.reports', session: 'hallbook.session' };
const uid = (prefix: string) => `${prefix}-${Math.random().toString(36).slice(2, 8)}-${Date.now().toString(36).slice(-4)}`;
const today = new Date();
const datePlus = (n: number) => { const d = new Date(today); d.setDate(d.getDate() + n); return d.toISOString().slice(0, 10); };

const seedHalls: Hall[] = [
  { hallId: 'hall-seminar', hallName: 'Seminar Hall', capacity: 48, location: 'Innovation Block · 1F', facilities: ['Projector', 'Whiteboard', 'Video conferencing'], description: 'A focused room for workshops, reading groups, and compact project reviews.', image: 'seminar', status: 'available' },
  { hallId: 'hall-auditorium', hallName: 'Main Auditorium', capacity: 280, location: 'Central Campus · Ground', facilities: ['Stage', 'Dual projection', 'PA system', 'Recording'], description: 'Our flagship gathering space for department talks, demos, and larger academic events.', image: 'auditorium', status: 'available' },
  { hallId: 'hall-conference', hallName: 'Conference Hall', capacity: 36, location: 'Research Wing · 2F', facilities: ['Display', 'Whiteboard', 'Hybrid audio'], description: 'A bright, boardroom-style space for research syncs and visiting faculty.', image: 'conference', status: 'available' },
  { hallId: 'hall-lab', hallName: 'Computer Lab', capacity: 64, location: 'Computing Centre · 3F', facilities: ['64 workstations', 'GPU access', 'Projector', 'Air conditioning'], description: 'Production-ready machines and GPU access for intensive AI and ML lab sessions.', image: 'lab', status: 'available' },
  { hallId: 'hall-mini', hallName: 'Mini Hall', capacity: 20, location: 'Learning Commons · 1F', facilities: ['Display', 'Whiteboard', 'Power outlets'], description: 'An intimate room for mentoring, interviews, and team retrospectives.', image: 'mini', status: 'available' },
];
const seedUsers: User[] = [
  { userId: 'usr-student', name: 'Aarav Mehta', email: 'student@example.com', phone: '+91 98765 43210', password: 'student123', role: 'student', status: 'active', createdAt: '2025-01-12' },
  { userId: 'usr-admin', name: 'Dr. Mira Sen', email: 'admin@example.com', phone: '+91 98765 10001', password: 'admin123', role: 'admin', status: 'active', createdAt: '2024-08-09' },
  { userId: 'usr-anika', name: 'Anika Rao', email: 'anika.rao@example.com', phone: '+91 98123 76540', password: 'welcome123', role: 'student', status: 'active', createdAt: '2025-02-21' },
  { userId: 'usr-rohan', name: 'Rohan Das', email: 'rohan.das@example.com', phone: '+91 98220 11561', password: 'welcome123', role: 'student', status: 'active', createdAt: '2025-03-01' },
];
const seedBookings: Booking[] = [
  { bookingId: 'BK-1042', userId: 'usr-student', hallId: 'hall-lab', date: datePlus(2), timeSlot: '10:00 – 11:30', status: 'confirmed', createdAt: datePlus(-4) },
  { bookingId: 'BK-1038', userId: 'usr-student', hallId: 'hall-seminar', date: datePlus(-6), timeSlot: '14:00 – 15:30', status: 'completed', createdAt: datePlus(-14) },
  { bookingId: 'BK-1029', userId: 'usr-student', hallId: 'hall-mini', date: datePlus(-16), timeSlot: '11:30 – 13:00', status: 'cancelled', createdAt: datePlus(-20) },
  { bookingId: 'BK-1041', userId: 'usr-anika', hallId: 'hall-auditorium', date: datePlus(4), timeSlot: '16:00 – 17:30', status: 'confirmed', createdAt: datePlus(-2) },
  { bookingId: 'BK-1036', userId: 'usr-rohan', hallId: 'hall-conference', date: datePlus(1), timeSlot: '09:00 – 10:00', status: 'confirmed', createdAt: datePlus(-3) },
  { bookingId: 'BK-1022', userId: 'usr-anika', hallId: 'hall-lab', date: datePlus(-12), timeSlot: '10:00 – 11:30', status: 'completed', createdAt: datePlus(-21) },
  { bookingId: 'BK-1018', userId: 'usr-rohan', hallId: 'hall-mini', date: datePlus(-20), timeSlot: '15:30 – 17:00', status: 'cancelled', createdAt: datePlus(-30) },
];

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) as T : fallback;
  } catch {
    localStorage.removeItem(key);
    return fallback;
  }
}
function write<T>(key: string, value: T) {
  localStorage.setItem(key, JSON.stringify(value));
  window.dispatchEvent(new Event('hallbook:data'));
}
export function initializeStore() { if (!localStorage.getItem(keys.users)) write(keys.users, seedUsers); if (!localStorage.getItem(keys.halls)) write(keys.halls, seedHalls); if (!localStorage.getItem(keys.bookings)) write(keys.bookings, seedBookings); if (!localStorage.getItem(keys.reports)) write(keys.reports, seedBookings.map((b) => ({ reportId: uid('report'), bookingId: b.bookingId, createdAt: b.createdAt }))); }

export const authService = {
  current: () => { initializeStore(); const id = localStorage.getItem(keys.session); return read<User[]>(keys.users, seedUsers).find((u) => u.userId === id) ?? null; },
  login: (email: string, password: string) => { initializeStore(); const user = read<User[]>(keys.users, seedUsers).find((u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password); if (!user) throw new Error('Email or password is incorrect.'); if (user.status === 'suspended') throw new Error('This account has been suspended.'); localStorage.setItem(keys.session, user.userId); return user; },
  register: (name: string, email: string, phone: string, password: string) => { initializeStore(); const users = read<User[]>(keys.users, seedUsers); if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) throw new Error('An account with this email already exists.'); const user = { userId: uid('usr'), name, email, phone, password, role: 'student' as Role, status: 'active' as UserStatus, createdAt: new Date().toISOString().slice(0, 10) }; write(keys.users, [...users, user]); localStorage.setItem(keys.session, user.userId); return user; },
  logout: () => { localStorage.removeItem(keys.session); window.dispatchEvent(new Event('hallbook:data')); },
  update: (id: string, data: Partial<Pick<User, 'name' | 'phone' | 'email' | 'password'>>) => {
    const users = read<User[]>(keys.users, seedUsers);
    if (data.email && users.some((u) => u.userId !== id && u.email.toLowerCase() === data.email!.trim().toLowerCase())) throw new Error('An account with this email already exists.');
    const next = users.map((u) => u.userId === id ? { ...u, ...data, email: data.email?.trim() ?? u.email } : u);
    write(keys.users, next);
    return next.find((u) => u.userId === id)!;
  },
  allUsers: () => read<User[]>(keys.users, seedUsers),
  setStatus: (id: string, status: UserStatus) => { const next = read<User[]>(keys.users, seedUsers).map((u) => u.userId === id ? { ...u, status } : u); write(keys.users, next); return next; },
};
export const hallService = {
  all: () => read<Hall[]>(keys.halls, seedHalls),
  get: (id: string) => read<Hall[]>(keys.halls, seedHalls).find((h) => h.hallId === id),
  save: (hall: Omit<Hall, 'hallId'> & { hallId?: string }) => { const halls = read<Hall[]>(keys.halls, seedHalls); const item = { ...hall, hallId: hall.hallId ?? uid('hall') }; write(keys.halls, hall.hallId ? halls.map((h) => h.hallId === item.hallId ? item : h) : [...halls, item]); return item; },
  remove: (id: string) => write(keys.halls, read<Hall[]>(keys.halls, seedHalls).filter((h) => h.hallId !== id)),
};
export const bookingService = {
  all: () => read<Booking[]>(keys.bookings, seedBookings),
  byUser: (id: string) => read<Booking[]>(keys.bookings, seedBookings).filter((b) => b.userId === id),
  get: (id: string) => read<Booking[]>(keys.bookings, seedBookings).find((b) => b.bookingId === id),
  isConflict: (hallId: string, date: string, timeSlot: string, exceptId?: string) => read<Booking[]>(keys.bookings, seedBookings).some((b) => b.hallId === hallId && b.date === date && b.timeSlot === timeSlot && b.status !== 'cancelled' && b.bookingId !== exceptId),
  create: (data: Pick<Booking, 'userId' | 'hallId' | 'date' | 'timeSlot'>) => {
    const hall = hallService.get(data.hallId);
    if (!hall) throw new Error('Please choose a valid hall.');
    if (hall.status === 'maintenance') throw new Error('This hall is currently under maintenance. Please choose another hall.');
    if (!data.date || data.date < new Date().toISOString().slice(0, 10)) throw new Error('Please choose a valid future date.');
    if (!timeSlots.includes(data.timeSlot)) throw new Error('Please choose a valid time slot.');
    if (bookingService.isConflict(data.hallId, data.date, data.timeSlot)) throw new Error('This hall is already booked for the selected time slot. Please choose another slot.');
    const item: Booking = { ...data, bookingId: `BK-${Math.floor(1000 + Math.random() * 8999)}`, status: 'confirmed', createdAt: new Date().toISOString().slice(0, 10) };
    write(keys.bookings, [...bookingService.all(), item]);
    return item;
  },
  update: (id: string, data: Pick<Booking, 'hallId' | 'date' | 'timeSlot'>, actorId?: string) => {
    const list = bookingService.all();
    const found = list.find((b) => b.bookingId === id);
    if (!found) throw new Error('Booking not found.');
    if (actorId && found.userId !== actorId) throw new Error('You can only change your own bookings.');
    if (found.status !== 'confirmed') throw new Error('Only confirmed bookings can be rescheduled.');
    const hall = hallService.get(data.hallId);
    if (!hall || hall.status === 'maintenance') throw new Error('This hall is not available for booking.');
    if (!data.date || data.date < new Date().toISOString().slice(0, 10) || !timeSlots.includes(data.timeSlot)) throw new Error('Please choose a valid future date and time.');
    if (bookingService.isConflict(data.hallId, data.date, data.timeSlot, id)) throw new Error('This hall is already booked for the selected time slot. Please choose another slot.');
    const next = list.map((b) => b.bookingId === id ? { ...b, ...data } : b);
    write(keys.bookings, next);
    return next.find((b) => b.bookingId === id)!;
  },
  setStatus: (id: string, status: BookingStatus, actorId?: string) => { const list = bookingService.all(); const found = list.find((b) => b.bookingId === id); if (!found) throw new Error('Booking not found.'); if (actorId && found.userId !== actorId) throw new Error('You can only change your own bookings.'); const next = list.map((b) => b.bookingId === id ? { ...b, status } : b); write(keys.bookings, next); return next.find((b) => b.bookingId === id)!; },
};
const defaultSettings: WorkspaceSettings = { reminders: true, autoApprove: false, window: '1.5 hours' };
export const settingsService = {
  get: () => read<WorkspaceSettings>('hallbook.settings', defaultSettings),
  save: (settings: WorkspaceSettings) => { write('hallbook.settings', settings); return settings; },
};
export const reportService = { all: () => read<Report[]>(keys.reports, []), exportCsv: () => { const halls = hallService.all(); const escape = (value: string) => `"${value.replaceAll('"', '""')}"`; const rows = bookingService.all().map((b) => [b.bookingId, halls.find((h) => h.hallId === b.hallId)?.hallName ?? '', b.date, b.timeSlot, b.status].map(escape).join(',')); const blob = new Blob([['Booking ID,Hall,Date,Time slot,Status', ...rows].join('\n')], { type: 'text/csv' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = 'hallbook-report.csv'; a.click(); URL.revokeObjectURL(url); } };
export const timeSlots = ['09:00 – 10:00', '10:00 – 11:30', '11:30 – 13:00', '14:00 – 15:30', '15:30 – 17:00', '17:00 – 18:30'];
export const formatDate = (value: string) => new Intl.DateTimeFormat('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(`${value}T12:00:00`));