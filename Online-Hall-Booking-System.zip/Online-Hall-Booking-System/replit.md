# HallBook — Online Hall Booking System

HallBook helps students discover campus halls, check availability, and create conflict-free reservations while giving administrators a focused view of users, spaces, bookings, and reports.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/hallbook/src/App.tsx` — route map and application shell
- `artifacts/hallbook/src/services/hallbook.ts` — centralized demo data, persistence, auth, booking rules, and admin CRUD
- `artifacts/hallbook/src/index.css` — shared HallBook theme, typography, responsive layout, and dark mode
- `artifacts/hallbook/src/pages/` — not-found boundary and route-local page support

## Architecture decisions

- The first build is frontend-only with a centralized localStorage service so the college demo works without requiring a hosted database.
- Booking conflict and ownership checks live in the service layer rather than components, keeping the OOP domain behavior explainable for the presentation.
- The app uses seeded sample data and demo accounts so every dashboard and report has meaningful content on first launch.

## Product

- Public landing, about, and project information pages
- Demo student and admin authentication flows
- Hall discovery, details, filters, availability, and multi-step booking
- Booking confirmation, printable cards, updates, cancellations, and empty states
- Admin dashboard analytics, user management, hall CRUD, booking management, reports, and settings
- Responsive navigation and class-based dark mode

## User preferences

_No persistent preferences recorded._

## Gotchas

- Demo credentials are intentionally local and educational: `student@example.com` / `student123` and `admin@example.com` / `admin123`.
- The frontend artifact uses the managed `artifacts/hallbook: web` workflow so `PORT` and `BASE_PATH` are supplied by the runtime.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
